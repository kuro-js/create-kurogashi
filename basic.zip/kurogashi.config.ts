import { defineConfig } from 'kurogashi';

export default defineConfig({});

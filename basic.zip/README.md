# Welcome to Kurogashi!

## Development server

```sh
bun run dev
```

## Building

```sh
bun run build
```

Visit our Github: https://github.com/kuro-js

import { defineEventHandler } from "kurogashi"

export default defineEventHandler((event) => {
    return "Welcome!"
})